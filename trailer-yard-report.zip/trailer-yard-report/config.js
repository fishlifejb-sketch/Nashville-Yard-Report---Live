// ============================================================
//  Trailer Yard Report: your settings
//  Fill these in once (see README.md), then upload to GitHub.
// ============================================================

window.YARD_CONFIG = {
  // 1) Firebase: paste the "firebaseConfig" values from
  //    Firebase console → Project settings → Your apps → Web app.
  firebase: {
    apiKey: "AIzaSyCfAXOVF6VlInhxlvoCUH9VsWvSO0NyVWQ",
    authDomain: "trailer-yard.firebaseapp.com",
    projectId: "trailer-yard",
    storageBucket: "trailer-yard.firebasestorage.app",
    messagingSenderId: "627326785751",
    appId: "1:627326785751:web:b928618381a092858b3892"
  },

  // 2) Google Sheet (optional): the Web app URL from your Apps Script
  //    deployment (ends in /exec), and the same secret word you typed
  //    into SECRET at the top of google-apps-script.gs.
  sheetRelayUrl: "",
  sheetRelaySecret: ""
};
